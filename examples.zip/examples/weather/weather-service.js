window.WeatherService = (function () {
  var DEFAULT_LAT = 1.2745;
  var DEFAULT_LON = 103.8436;

  var WMO_DESCRIPTIONS = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Foggy",
    48: "Depositing rime fog",
    51: "Light drizzle",
    53: "Moderate drizzle",
    55: "Dense drizzle",
    61: "Light rain",
    63: "Moderate rain",
    65: "Heavy rain",
    66: "Light freezing rain",
    67: "Heavy freezing rain",
    71: "Light snow",
    73: "Moderate snow",
    75: "Heavy snow",
    80: "Light rain showers",
    81: "Moderate rain showers",
    82: "Violent rain showers",
    95: "Thunderstorm",
    96: "Thunderstorm with hail",
    99: "Thunderstorm with heavy hail",
  };

  var cachedLocationName = null;

  function getLocation() {
    return new Promise(function (resolve) {
      if (!navigator.geolocation) {
        resolve({ latitude: DEFAULT_LAT, longitude: DEFAULT_LON, isDefault: true });
        return;
      }
      navigator.geolocation.getCurrentPosition(
        function (pos) {
          resolve({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            isDefault: false,
          });
        },
        function () {
          resolve({ latitude: DEFAULT_LAT, longitude: DEFAULT_LON, isDefault: true });
        },
        { timeout: 10000, maximumAge: 300000 }
      );
    });
  }

  function reverseGeocode(latitude, longitude) {
    if (cachedLocationName) return Promise.resolve(cachedLocationName);

    var url = "https://nominatim.openstreetmap.org/reverse" +
      "?lat=" + latitude +
      "&lon=" + longitude +
      "&format=json&zoom=14";

    return fetch(url, {
      headers: { "Accept-Language": "en" },
    })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        var addr = data.address || {};
        var name = addr.suburb || addr.neighbourhood || addr.town ||
          addr.city_district || addr.village || addr.city || addr.county || "";
        cachedLocationName = name;
        return name;
      })
      .catch(function () {
        return "";
      });
  }

  function fetchWeather(latitude, longitude) {
    var url =
      "https://api.open-meteo.com/v1/forecast" +
      "?latitude=" + latitude +
      "&longitude=" + longitude +
      "&current=temperature_2m,precipitation,cloud_cover,weather_code" +
      "&hourly=temperature_2m,precipitation,cloud_cover" +
      "&timezone=auto" +
      "&forecast_days=2";

    var controller = new AbortController();
    var timeoutId = setTimeout(function () { controller.abort(); }, 10000);

    return fetch(url, { signal: controller.signal })
      .then(function (res) {
        clearTimeout(timeoutId);
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.json();
      });
  }

  function normalizeData(api) {
    var hourly = api.hourly.time.map(function (time, i) {
      return {
        time: time,
        temperature: api.hourly.temperature_2m[i],
        rainfall: api.hourly.precipitation[i],
        cloudCover: api.hourly.cloud_cover[i],
      };
    });

    return {
      location: api.latitude.toFixed(2) + ", " + api.longitude.toFixed(2),
      isDemo: false,
      updatedAt: new Date().toISOString(),
      current: {
        temperature: api.current.temperature_2m,
        rainfall: api.current.precipitation,
        cloudCover: api.current.cloud_cover,
        weatherCode: api.current.weather_code,
      },
      hourly: hourly,
    };
  }

  function getWeatherDescription(code) {
    return WMO_DESCRIPTIONS[code] || "Unknown";
  }

  function getNextHours(data, count) {
    if (!data || !data.hourly) return [];
    var now = Date.now();
    var future = data.hourly.filter(function (h) {
      return new Date(h.time).getTime() >= now - 30 * 60 * 1000;
    });
    return future.slice(0, count);
  }

  function getRainfallLabel(mm) {
    if (mm === 0) return "None";
    if (mm < 2.5) return "Light";
    if (mm < 7.5) return "Moderate";
    return "Heavy";
  }

  function getCloudLabel(pct) {
    if (pct < 20) return "Clear";
    if (pct < 50) return "Partly cloudy";
    if (pct < 80) return "Mostly cloudy";
    return "Overcast";
  }

  function resolveLocationName(loc) {
    if (loc.isDefault) return Promise.resolve("Tanjong Pagar");
    return reverseGeocode(loc.latitude, loc.longitude).then(function (name) {
      return name || loc.latitude.toFixed(3) + ", " + loc.longitude.toFixed(3);
    });
  }

  function getWeatherData() {
    return getLocation().then(function (loc) {
      var namePromise = resolveLocationName(loc);
      function tag(data, name) {
        data.location = name;
        data.locationIsDefault = !!loc.isDefault;
        data.coords = { lat: loc.latitude, lon: loc.longitude };
        return data;
      }
      return Promise.all([fetchWeather(loc.latitude, loc.longitude), namePromise])
        .then(function (results) {
          return tag(normalizeData(results[0]), results[1]);
        })
        .catch(function (err) {
          console.warn("Weather API failed, using demo data:", err.message);
          return namePromise.then(function (name) {
            return tag(window.DemoData.get(), name);
          });
        });
    });
  }

  function formatRadarTimestamp(date) {
    var sgt = new Date(date.getTime() + (8 * 60 * 60 * 1000));
    var minute = Math.floor(sgt.getUTCMinutes() / 5) * 5;
    sgt.setUTCMinutes(minute, 0, 0);

    var y = sgt.getUTCFullYear();
    var mo = String(sgt.getUTCMonth() + 1).padStart(2, "0");
    var d = String(sgt.getUTCDate()).padStart(2, "0");
    var h = String(sgt.getUTCHours()).padStart(2, "0");
    var mi = String(sgt.getUTCMinutes()).padStart(2, "0");
    return y + mo + d + h + mi;
  }

  function getRainRadarUrl() {
    var now = new Date(Date.now() - 5 * 60 * 1000);
    var ts = formatRadarTimestamp(now);
    return "https://www.weather.gov.sg/files/rainarea/50km/v2/dpsri_70km_" + ts + "0000dBR.dpsri.png";
  }

  function getRainRadarUrlForTime(date) {
    var ts = formatRadarTimestamp(date);
    return "https://www.weather.gov.sg/files/rainarea/50km/v2/dpsri_70km_" + ts + "0000dBR.dpsri.png";
  }

  var RADAR_BOUNDS = [[1.156, 103.565], [1.475, 104.130]];

  function fetchStationRainfall() {
    return fetch("https://api.data.gov.sg/v1/environment/rainfall")
      .then(function (res) { return res.json(); })
      .then(function (data) {
        var stationMap = {};
        data.metadata.stations.forEach(function (s) {
          stationMap[s.id] = s;
        });
        return data.items[0].readings.map(function (r) {
          var s = stationMap[r.station_id];
          return {
            id: r.station_id,
            name: s ? s.name : r.station_id,
            lat: s ? s.location.latitude : 0,
            lon: s ? s.location.longitude : 0,
            value: r.value,
          };
        });
      })
      .catch(function () { return []; });
  }

  function fetchAreaForecast() {
    return fetch("https://api.data.gov.sg/v1/environment/2-hour-weather-forecast")
      .then(function (res) { return res.json(); })
      .then(function (data) {
        var areaMap = {};
        data.area_metadata.forEach(function (a) {
          areaMap[a.name] = a.label_location;
        });
        return data.items[0].forecasts.map(function (f) {
          var loc = areaMap[f.area] || {};
          return {
            area: f.area,
            forecast: f.forecast,
            lat: loc.latitude || 0,
            lon: loc.longitude || 0,
          };
        });
      })
      .catch(function () { return []; });
  }

  function fetchPSI() {
    return fetch("https://api.data.gov.sg/v1/environment/psi")
      .then(function (res) { return res.json(); })
      .then(function (data) {
        var readings = data.items[0].readings.psi_twenty_four_hourly;
        var values = Object.values(readings);
        var avg = Math.round(values.reduce(function (a, b) { return a + b; }, 0) / values.length);
        return { value: avg, regions: readings };
      })
      .catch(function () { return null; });
  }

  function getPSILabel(value) {
    if (value <= 50) return "Good";
    if (value <= 100) return "Moderate";
    if (value <= 200) return "Unhealthy";
    if (value <= 300) return "Very unhealthy";
    return "Hazardous";
  }

  function fetchMapData() {
    return Promise.all([
      fetchStationRainfall(),
      fetchAreaForecast(),
    ]).then(function (results) {
      return {
        radarUrl: getRainRadarUrl(),
        radarBounds: RADAR_BOUNDS,
        stations: results[0],
        forecasts: results[1],
      };
    });
  }

  function startAutoRefresh(callback, intervalMs) {
    if (!intervalMs) intervalMs = 300000;
    var timer = null;

    function refresh() {
      var weatherResult = null;
      var mapResult = null;

      getWeatherData()
        .then(function (w) { weatherResult = w; })
        .catch(function () { weatherResult = window.DemoData.get(); })
        .then(function () { return fetchPSI(); })
        .then(function (psi) { if (weatherResult && psi) weatherResult.psi = psi; })
        .catch(function () {})
        .then(function () { return fetchMapData(); })
        .then(function (m) { mapResult = m; })
        .catch(function () { mapResult = { radarUrl: null, radarBounds: RADAR_BOUNDS, stations: [], forecasts: [] }; })
        .then(function () {
          callback(weatherResult, mapResult);
        });
    }

    refresh();
    timer = setInterval(refresh, intervalMs);

    return function () {
      if (timer) clearInterval(timer);
    };
  }

  return {
    getWeatherData: getWeatherData,
    startAutoRefresh: startAutoRefresh,
    getNextHours: getNextHours,
    getWeatherDescription: getWeatherDescription,
    getRainfallLabel: getRainfallLabel,
    getCloudLabel: getCloudLabel,
    fetchMapData: fetchMapData,
    fetchPSI: fetchPSI,
    getPSILabel: getPSILabel,
    getRainRadarUrl: getRainRadarUrl,
    getRainRadarUrlForTime: getRainRadarUrlForTime,
    DEFAULT_COORDS: { lat: DEFAULT_LAT, lon: DEFAULT_LON },
    RADAR_BOUNDS: RADAR_BOUNDS,
  };
})();
