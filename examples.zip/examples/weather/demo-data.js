window.DemoData = {
  get: function () {
    var now = new Date();
    var currentHour = now.getHours();
    var hourly = [];

    for (var h = 0; h < 24; h++) {
      var time = new Date(now);
      time.setHours(h, 0, 0, 0);

      var hourOffset = h - currentHour;
      var rainfall = 0;
      if (h >= currentHour && h <= currentHour + 6) {
        var progress = (h - currentHour) / 6;
        if (progress < 0.5) {
          rainfall = 1.0 + progress * 12;
        } else {
          rainfall = 7.0 - (progress - 0.5) * 12;
        }
        rainfall = Math.max(0, Math.round(rainfall * 10) / 10);
      }

      var cloudBase = 60;
      var cloudPeak = h >= currentHour + 1 && h <= currentHour + 4 ? 94 : cloudBase;
      var cloudCover = Math.min(100, Math.round(
        cloudBase + (cloudPeak - cloudBase) * Math.max(0, 1 - Math.abs(h - (currentHour + 2.5)) / 3)
      ));

      var tempBase = 28;
      var temperature = Math.round((tempBase + Math.sin((h - 6) * Math.PI / 12) * 3) * 10) / 10;

      var yyyy = time.getFullYear();
      var mm = String(time.getMonth() + 1).padStart(2, "0");
      var dd = String(time.getDate()).padStart(2, "0");
      var hh = String(time.getHours()).padStart(2, "0");
      var localIso = yyyy + "-" + mm + "-" + dd + "T" + hh + ":00";

      hourly.push({
        time: localIso,
        temperature: temperature,
        rainfall: rainfall,
        cloudCover: cloudCover,
      });
    }

    var currentIdx = hourly.findIndex(function (h) {
      return new Date(h.time).getHours() === currentHour;
    });
    var current = currentIdx >= 0 ? hourly[currentIdx] : hourly[0];

    return {
      location: "Tanjong Pagar (demo data)",
      isDemo: true,
      updatedAt: now.toISOString(),
      current: {
        temperature: current.temperature,
        rainfall: current.rainfall,
        cloudCover: current.cloudCover,
        weatherCode: current.rainfall > 2 ? 63 : current.rainfall > 0 ? 61 : current.cloudCover > 80 ? 3 : 2,
      },
      hourly: hourly,
    };
  },
};
