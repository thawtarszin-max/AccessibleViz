/* Weather Explorer adapter: everything the kit needs to know about this dataset. */
window.createWeatherAdapter = function () {
  var WS = window.WeatherService;

  function hr(iso) {
    var h = new Date(iso).getHours();
    return (h % 12 || 12) + " " + (h >= 12 ? "PM" : "AM");
  }
  function clock(d) {
    var h = d.getHours(), m = d.getMinutes();
    return (h % 12 || 12) + ":" + String(m).padStart(2, "0") + " " + (h >= 12 ? "PM" : "AM");
  }
  function ago(iso) {
    var s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
    if (s < 60) return "just now";
    var m = Math.floor(s / 60);
    if (m < 60) return m + (m === 1 ? " minute ago" : " minutes ago");
    var h = Math.floor(m / 60);
    return h + (h === 1 ? " hour ago" : " hours ago");
  }
  function next(state, n) { return state && state.weather ? WS.getNextHours(state.weather, n) : []; }

  // Map time slider: -2h to +6h in 30-minute steps; index 4 is now.
  var STEPS = 17, STEP_MIN = 30, NOW = 4;
  var slider = NOW;
  function offsetMin() { return (slider - NOW) * STEP_MIN; }
  function sliderTime() { return new Date(Date.now() + offsetMin() * 60000); }
  function offsetLabel(o) {
    if (o === 0) return "Now";
    var h = Math.abs(o) / 60;
    return (o < 0 ? "-" : "+") + (h === Math.floor(h) ? h : h.toFixed(1)) + "h";
  }

  var REGION = {
    "Jurong East": "west", "Jurong West": "west", "Bukit Batok": "west", "Bukit Panjang": "west",
    "Choa Chu Kang": "west", "Boon Lay": "west", "Pioneer": "west", "Tuas": "west", "Clementi": "west",
    "Western Water Catchment": "west", "Tengah": "west", "Lim Chu Kang": "west",
    "Ang Mo Kio": "north", "Yishun": "north", "Sembawang": "north", "Woodlands": "north", "Mandai": "north", "Sungei Kadut": "north",
    "Bedok": "east", "Changi": "east", "Pasir Ris": "east", "Tampines": "east", "Paya Lebar": "east",
    "Hougang": "east", "Punggol": "east", "Sengkang": "east", "Serangoon": "east",
    "Bishan": "central", "Toa Payoh": "central", "Novena": "central", "Bukit Timah": "central", "Newton": "central",
    "Orchard": "central", "Queenstown": "central", "Bukit Merah": "central", "City": "central",
    "Central Water Catchment": "central", "Tanglin": "central", "Tanjong Pagar": "central",
    "Marine Parade": "south", "Geylang": "south", "Kallang": "south", "Sentosa": "south", "Southern Islands": "south",
  };

  function describeForecast(forecasts) {
    var heavy = [], light = [], clear = [];
    forecasts.forEach(function (f) {
      var l = f.forecast.toLowerCase();
      if (l.indexOf("heavy") >= 0) heavy.push(f.area);
      else if (/shower|rain|thunder/.test(l)) light.push(f.area);
      else clear.push(f.area);
    });
    function regions(a) {
      var r = {};
      a.forEach(function (x) { if (REGION[x]) r[REGION[x]] = true; });
      return Object.keys(r);
    }
    function names(a, max) { return a.length <= max ? a.join(", ") : a.slice(0, max).join(", ") + " and " + (a.length - max) + " more areas"; }
    var parts = [];
    if (heavy.length) {
      var hr_ = regions(heavy);
      parts.push("Heavy rain concentrated in " + names(heavy, 3) + (hr_.length ? ", mainly across the " + hr_.join(" and ") + " region" + (hr_.length > 1 ? "s" : "") : "") + ".");
    }
    if (light.length) {
      var lr = regions(light);
      parts.push(light.length > 10
        ? "Light to moderate showers covering much of Singapore" + (lr.length ? ", especially in the " + lr.join(", ") : "") + "."
        : "Showers around " + names(light, 4) + ".");
    }
    if (!heavy.length && !light.length) parts.push("No significant rainfall across Singapore. Clear conditions across the island.");
    if (clear.length && (heavy.length || light.length)) parts.push("Drier conditions in " + names(clear, 3) + ".");
    return parts.join(" ");
  }

  function mapDescription(state) {
    if (!state || !state.map) return "Loading rain map data.";
    var o = offsetMin(), t = clock(sliderTime());
    var where = slider === NOW ? "Now" : offsetLabel(o) + ", " + t;
    if (o < 0) return where + ". Showing radar data from " + t + ". Slide to Now for the latest conditions.";
    var base = state.map.forecasts && state.map.forecasts.length ? describeForecast(state.map.forecasts) : "No area forecast available.";
    if (o / 60 <= 2) return where + ". " + base;
    if (o / 60 <= 4) return where + ". Based on the current trend, conditions may shift. " + base + " Forecast confidence decreases further out.";
    return where + ". Extended outlook. Conditions this far ahead are less certain. Check back closer to the time for a more accurate picture.";
  }

  function lineChart(slot, label, unit, color, fill, rows) {
    if (!slot._chart) {
      var canvas = document.createElement("canvas");
      slot.append(canvas);
      var reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      slot._chart = new Chart(canvas, {
        type: "line",
        data: { labels: [], datasets: [{ label: label, data: [], borderColor: color, backgroundColor: fill || "transparent", fill: !!fill, tension: 0.3, pointRadius: 3, borderWidth: 2 }] },
        options: {
          responsive: true, animation: { duration: reduced ? 0 : 600 },
          plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { return c.parsed.y + " " + unit; } } } },
          scales: { x: { title: { display: true, text: "Time" }, grid: { display: false } }, y: { title: { display: true, text: label + " (" + unit + ")" }, beginAtZero: true } },
        },
      });
    }
    slot._chart.data.labels = rows.map(function (r) { return hr(r.time); });
    slot._chart.data.datasets[0].data = rows.map(function (r) { return r.value; });
    slot._chart.update();
  }

  return {
    topic: "the weather",
    purpose: "Weather Explorer. A live weather dashboard with a rain map, hourly charts, and a chat box to ask about the weather.",
    chatLabel: "Ask about the weather",
    chatIntro: "Ask me anything about the weather. I'm here to help you plan your day.",
    suggestions: [
      "When's a good time to head outside?",
      "Will it rain in the next hour?",
      "When will the rain be heaviest?",
      "How's the air quality today?",
    ],

    headline: function (s) {
      if (!s || !s.weather) return "Loading weather…";
      return WS.getWeatherDescription(s.weather.current.weatherCode) + (s.weather.location ? " in " + s.weather.location : "");
    },
    summary: function (s) {
      if (!s || !s.weather) return "";
      var c = s.weather.current, hrs = next(s, 6);
      var parts = ["It's " + c.temperature + " degrees Celsius right now."];
      if (s.weather.locationIsDefault) parts.unshift("Location access is off, so this shows the default location.");
      if (!hrs.length) return parts.join(" ");
      var rainy = hrs.filter(function (x) { return x.rainfall > 0; });
      var peak = hrs.reduce(function (a, b) { return a.rainfall > b.rainfall ? a : b; });
      if (!rainy.length) parts.push("No rain on the horizon.");
      else if (rainy.length >= hrs.length - 1) parts.push("Rain expected throughout the day, heaviest around " + hr(peak.time) + ".");
      else parts.push("Some rain coming around " + hr(rainy[0].time) + ", heaviest near " + hr(peak.time) + ".");
      var diff = hrs[hrs.length - 1].temperature - c.temperature;
      if (diff >= 2) parts.push("Warming up to " + hrs[hrs.length - 1].temperature + " degrees later.");
      else if (diff <= -2) parts.push("Cooling down to " + hrs[hrs.length - 1].temperature + " degrees later.");
      return parts.join(" ");
    },

    vizTitle: "Weather near you",
    vizDescription: "Current conditions, a rain radar map with a time scrubber, and hourly rainfall and cloud cover charts.",
    note: function (s) {
      if (!s || !s.weather) return "";
      return (s.weather.isDemo ? "Demo data. " : "Live data. ") + "Updated " + ago(s.weather.updatedAt) + ".";
    },
    dataNote: "Forecasts from Open-Meteo; radar, rainfall and air quality from data.gov.sg.",

    figuresLabel: "Current conditions",
    keyFigures: function (s) {
      if (!s || !s.weather) return [];
      var c = s.weather.current, psi = s.weather.psi ? s.weather.psi.value : null;
      return [
        { label: "Temperature", value: c.temperature + "°C", spoken: c.temperature + " degrees Celsius" },
        { label: "Air quality (PSI)", value: psi != null ? psi : "…", spoken: psi != null ? String(psi) : "Loading", status: psi != null ? WS.getPSILabel(psi) : "" },
        { label: "Rainfall", value: c.rainfall + " mm", spoken: c.rainfall + " millimetres", status: WS.getRainfallLabel(c.rainfall) },
        { label: "Cloud cover", value: c.cloudCover + "%", spoken: c.cloudCover + " per cent", status: WS.getCloudLabel(c.cloudCover) },
      ];
    },

    viewsTitle: "Rain and forecast",
    views: [
      {
        id: "map",
        name: "Map",
        interactive: true, // contains the slider; the map itself is hidden below
        describe: mapDescription,
        render: function (slot, s, kit) {
          if (!s || !s.map) return;
          if (!slot._map) {
            var mapDiv = document.createElement("div");
            mapDiv.setAttribute("aria-hidden", "true");
            mapDiv.style.cssText = "height:420px;border-radius:8px;border:1px solid #DFDFDF;overflow:hidden;background:#F7F7F7;";
            var legend = document.createElement("p");
            legend.setAttribute("aria-hidden", "true");
            legend.style.cssText = "display:flex;flex-wrap:wrap;align-items:center;gap:16px;font-size:0.75rem;color:var(--av-text-2);margin:0;padding:8px 0;";
            legend.innerHTML = "<span style=\"font-weight:600\">Radar:</span>" + [["#78c8ff", "Light"], ["#00c800", "Moderate"], ["#ffff00", "Heavy"], ["#ff0000", "Intense"]]
              .map(function (x) { return '<span style="display:inline-flex;gap:4px;align-items:center"><span style="width:12px;height:12px;border-radius:2px;background:' + x[0] + '"></span>' + x[1] + "</span>"; }).join("");
            var head = document.createElement("div");
            head.setAttribute("aria-hidden", "true");
            head.style.cssText = "display:flex;justify-content:space-between;align-items:center;font-size:0.8rem;margin:8px 0 4px;";
            var range = document.createElement("input");
            range.type = "range"; range.min = 0; range.max = STEPS - 1; range.value = slider;
            range.style.cssText = "width:100%;margin:0;cursor:pointer;accent-color:var(--av-primary);";
            range.setAttribute("aria-label", "Time scrubber. Explore rainfall over 8 hours");
            range.addEventListener("input", function () {
              slider = parseInt(range.value, 10);
              kit.update();
              kit.announce(mapDescription(slot._state)); // once, after the user stops moving
            });
            slot.append(mapDiv, legend, head, range);
            var map = L.map(mapDiv, { center: [1.3521, 103.8198], zoom: 11, zoomControl: false, attributionControl: false, keyboard: false });
            L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 18, className: "av-map-tiles" }).addTo(map);
            slot._map = map; slot._range = range; slot._head = head;
          }
          slot._state = s; // latest state for the slider handler (avoid stale closures)
          var o = offsetMin(), url = o < 0 ? WS.getRainRadarUrlForTime(sliderTime()) : s.map.radarUrl;
          if (url && s.map.radarBounds) {
            if (!slot._radar) slot._radar = L.imageOverlay(url, s.map.radarBounds, { opacity: 0.5, interactive: false }).addTo(slot._map);
            else slot._radar.setUrl(url);
          }
          slot._range.value = slider;
          slot._range.setAttribute("aria-valuetext", slider === NOW ? "Now" : offsetLabel(o) + ", " + clock(sliderTime()));
          slot._head.innerHTML = "<span style=\"font-weight:600\">" + offsetLabel(o) + "</span><span style=\"color:var(--av-text-2);font-variant-numeric:tabular-nums\">" + clock(sliderTime()) + "</span>";
          setTimeout(function () { slot._map.invalidateSize(); }, 0);
        },
      },
      {
        id: "rain",
        name: "Rainfall",
        describe: function (s) {
          var hrs = next(s, 8);
          if (hrs.length < 2) return "No rainfall data yet.";
          var rainy = hrs.filter(function (x) { return x.rainfall > 0; });
          if (!rainy.length) return "No rainfall expected over the next " + hrs.length + " hours.";
          var peak = hrs.reduce(function (a, b) { return a.rainfall > b.rainfall ? a : b; });
          var dry = hrs.filter(function (x) { return x.rainfall === 0; });
          var t = "Rainfall over the next " + hrs.length + " hours peaks at " + peak.rainfall + " millimetres (" + WS.getRainfallLabel(peak.rainfall).toLowerCase() + ") around " + hr(peak.time) + ".";
          if (dry.length) t += " The driest window looks to be around " + hr(dry.reduce(function (b, x) { return x.cloudCover < b.cloudCover ? x : b; }).time) + ".";
          return t;
        },
        table: function (s) {
          return { caption: "Hourly rainfall", columns: ["Time", "Rainfall (millimetres)"], rows: next(s, 8).map(function (x) { return [hr(x.time), x.rainfall]; }) };
        },
        render: function (slot, s) {
          lineChart(slot, "Rainfall", "mm", "#0269D0", "rgba(2,105,208,0.12)", next(s, 8).map(function (x) { return { time: x.time, value: x.rainfall }; }));
        },
      },
      {
        id: "cloud",
        name: "Cloud cover",
        describe: function (s) {
          var hrs = next(s, 8);
          if (hrs.length < 2) return "No cloud cover data yet.";
          var max = hrs.reduce(function (a, b) { return a.cloudCover > b.cloudCover ? a : b; });
          var min = hrs.reduce(function (a, b) { return a.cloudCover < b.cloudCover ? a : b; });
          var first = hrs[0].cloudCover, last = hrs[hrs.length - 1].cloudCover;
          if (max.cloudCover - min.cloudCover <= 15) {
            return first < 40 ? "Mostly clear skies ahead." : first < 70 ? "Partly cloudy throughout." : "Overcast skies expected to continue.";
          }
          if (last - first > 15) return "Cloud cover is increasing from " + first + " to " + last + " per cent, peaking at " + max.cloudCover + " per cent around " + hr(max.time) + ".";
          if (first - last > 15) return "Cloud cover is clearing from " + first + " to " + last + " per cent, lightest around " + hr(min.time) + ".";
          return "Cloud cover ranges from " + min.cloudCover + " to " + max.cloudCover + " per cent, peaking around " + hr(max.time) + ".";
        },
        table: function (s) {
          return { caption: "Hourly cloud cover", columns: ["Time", "Cloud cover (per cent)"], rows: next(s, 8).map(function (x) { return [hr(x.time), x.cloudCover]; }) };
        },
        render: function (slot, s) {
          lineChart(slot, "Cloud cover", "%", "#525252", null, next(s, 8).map(function (x) { return { time: x.time, value: x.cloudCover }; }));
        },
      },
    ],

    // The chat moved to a time: move the slider too. The kit keeps this quiet.
    onAnswer: function (res, kit) {
      if (!res.focusTime) return;
      var o = (new Date(res.focusTime).getTime() - Date.now()) / 60000;
      slider = Math.max(0, Math.min(STEPS - 1, NOW + Math.round(o / STEP_MIN)));
      kit.showView("map");
      kit.update();
    },
  };
};

// Chat: the existing rule engine, wrapped as a kit engine (any object with ask()).
window.weatherRules = {
  ask: function (q, ctx) {
    var s = ctx.state || {};
    var r = window.QueryEngine.processQuery(q, s.weather, s.map);
    return r;
  },
};
