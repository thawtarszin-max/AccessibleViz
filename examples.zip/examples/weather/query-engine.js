window.QueryEngine = (function () {
  var context = {
    lastReferencedTime: null,
    lastIntent: null,
  };

  function formatTime(isoString) {
    var d = new Date(isoString);
    var h = d.getHours();
    var suffix = h >= 12 ? "PM" : "AM";
    var hour12 = h % 12 || 12;
    return hour12 + " " + suffix;
  }

  function formatTimeRange(startIso, endIso) {
    return formatTime(startIso) + " to " + formatTime(endIso);
  }

  var WS = window.WeatherService;

  var FOLLOWUP_PATTERNS = [
    /what.{0,10}(about|like|be).{0,5}then/i,
    /at that time/i,
    /tell me more/i,
    /what.{0,5}(temperature|rain|cloud|weather).{0,5}then/i,
  ];

  var INTENTS = [
    {
      id: "CURRENT_CONDITIONS",
      patterns: [
        /what('s| is) the weather/i,
        /current (weather|conditions|temperature)/i,
        /weather (right )?now/i,
        /is it raining/i,
        /how (hot|cold|warm)/i,
        /what's it like (outside|right now|now)/i,
      ],
      keywords: ["now", "current", "currently", "raining", "right now", "outside", "at the moment"],
    },
    {
      id: "NEXT_HOUR_RAIN",
      patterns: [
        /rain.{0,20}next.{0,5}(1 |one )?hour/i,
        /will it rain soon/i,
        /rain.*soon/i,
        /about to rain/i,
        /should I bring.*(umbrella|jacket)/i,
        /is it going to rain/i,
      ],
      keywords: ["next hour", "soon", "umbrella", "about to rain"],
    },
    {
      id: "RAIN_TREND",
      patterns: [
        /rain.*(getting|become|becoming).*(worse|heavier|lighter|better)/i,
        /will it rain more/i,
        /rain.*(increase|decrease|stop|ease|let up)/i,
        /(getting|become) (worse|heavier|lighter)/i,
      ],
      keywords: ["worse", "better", "more rain", "less rain", "stop raining", "letting up", "ease"],
    },
    {
      id: "PEAK_RAIN",
      patterns: [
        /when.*(heaviest|peak|worst|most).*(rain)?/i,
        /rain.*(peak|heaviest|worst)/i,
        /most rain/i,
        /heaviest rain/i,
      ],
      keywords: ["peak", "heaviest", "worst rain", "most rain"],
    },
    {
      id: "OUTDOOR_WINDOW",
      patterns: [
        /best time.*(outside|outdoor|walk|run|jog|exercise)/i,
        /when (should|can|could) I go (outside|out)/i,
        /good time.*(outside|outdoor)/i,
        /safe to go out/i,
        /when.*(go for a walk|go outside|head out)/i,
      ],
      keywords: ["outside", "outdoor", "walk", "run", "go out", "best time", "exercise", "jog"],
    },
    {
      id: "WEATHER_TREND",
      patterns: [
        /how (will|does).*(weather|it) change/i,
        /what('s| is) happening.*(afternoon|evening|tonight|later|next few)/i,
        /forecast/i,
        /rest of (the )?day/i,
        /next few hours/i,
        /what should I (know|expect)/i,
      ],
      keywords: ["change", "later", "afternoon", "evening", "forecast", "trend", "next few hours"],
    },
    {
      id: "CLOUD_COVER",
      patterns: [
        /cloud(y|s| cover)/i,
        /will it (get |be |become )?cloud/i,
        /sun(ny|shine)/i,
        /overcast/i,
        /clear (up|skies)/i,
      ],
      keywords: ["cloud", "cloudy", "sunny", "overcast", "clear", "sun"],
    },
    {
      id: "AIR_QUALITY",
      patterns: [
        /air quality/i,
        /psi/i,
        /haze|hazy/i,
        /pollution/i,
        /safe to breathe/i,
      ],
      keywords: ["air", "quality", "psi", "haze", "pollution", "breathe"],
    },
  ];

  function scoreIntent(intent, query) {
    var score = 0;
    intent.patterns.forEach(function (p) {
      if (p.test(query)) score += 3;
    });
    intent.keywords.forEach(function (kw) {
      if (query.toLowerCase().indexOf(kw.toLowerCase()) >= 0) score += 1;
    });
    return score;
  }

  function matchIntent(query) {
    var normalized = query.toLowerCase().trim().replace(/\s+/g, " ");

    for (var i = 0; i < FOLLOWUP_PATTERNS.length; i++) {
      if (FOLLOWUP_PATTERNS[i].test(normalized) && context.lastReferencedTime) {
        return { id: "FOLLOWUP", time: context.lastReferencedTime };
      }
    }

    var bestIntent = null;
    var bestScore = 0;
    INTENTS.forEach(function (intent) {
      var s = scoreIntent(intent, normalized);
      if (s > bestScore) {
        bestScore = s;
        bestIntent = intent;
      }
    });

    if (bestScore >= 1 && bestIntent) {
      return { id: bestIntent.id };
    }
    return { id: "UNKNOWN" };
  }

  // --- Intent handlers ---

  function handleCurrentConditions(data) {
    var c = data.current;
    var desc = WS.getWeatherDescription(c.weatherCode);
    var rainLabel = WS.getRainfallLabel(c.rainfall);

    var text;
    if (c.rainfall > 0) {
      text = "It's raining right now. " + rainLabel.charAt(0).toUpperCase() + rainLabel.slice(1).toLowerCase() + " rainfall at about " +
        c.rainfall + " mm. Temperature is " + c.temperature + "°C with " +
        c.cloudCover + "% cloud cover. You might want to keep an umbrella close by.";
    } else if (c.cloudCover > 80) {
      text = "It's " + c.temperature + "°C and quite overcast at " + c.cloudCover +
        "% cloud cover, but no rain at the moment. A good time to step out if you need to. Just keep an umbrella handy in case.";
    } else if (c.cloudCover < 30) {
      text = "It's a lovely " + c.temperature + "°C with clear skies right now. " +
        "Great conditions to be outdoors. Don't forget some sun protection if you're heading out!";
    } else {
      text = desc + " and " + c.temperature + "°C right now, with " +
        c.cloudCover + "% cloud cover. No rain at the moment. A nice time to enjoy some fresh air.";
    }

    context.lastReferencedTime = null;
    context.lastIntent = "CURRENT_CONDITIONS";
    return { text: text, highlightedHours: [], chartFocus: null };
  }

  function handleNextHourRain(data) {
    var nextHours = WS.getNextHours(data, 2);
    if (nextHours.length === 0) {
      return { text: "I don't have enough forecast data for the next hour right now. Please check back shortly.", highlightedHours: [], chartFocus: "rainfall" };
    }

    var hasRain = nextHours.some(function (h) { return h.rainfall > 0; });
    var highlighted = nextHours.map(function (h) { return h.time; });
    var text;

    if (hasRain) {
      var maxInNext = nextHours.reduce(function (a, b) { return a.rainfall > b.rainfall ? a : b; });
      var trend = nextHours.length > 1 && nextHours[1].rainfall > nextHours[0].rainfall ? "picking up" : "easing a little";
      text = "Yes, it looks like " + WS.getRainfallLabel(maxInNext.rainfall).toLowerCase() +
        " rain is on the way over the next hour, " + trend + " toward " +
        formatTime(nextHours[nextHours.length - 1].time) +
        ". It's a good idea to grab an umbrella if you're heading out.";
    } else {
      text = "You're in the clear for the next hour. No rain expected. A good window to step outside if you need to.";
      var futureRain = WS.getNextHours(data, 6).filter(function (h) { return h.rainfall > 0; });
      if (futureRain.length > 0) {
        text += " Just a heads up though.rain may arrive around " + formatTime(futureRain[0].time) +
          ", so don't wander too far without an umbrella.";
      }
    }

    context.lastReferencedTime = nextHours[0].time;
    context.lastIntent = "NEXT_HOUR_RAIN";
    return { text: text, highlightedHours: highlighted, chartFocus: "rainfall" };
  }

  function handleRainTrend(data) {
    var hours = WS.getNextHours(data, 6);
    if (hours.length < 2) {
      return { text: "I don't have enough data to show the rainfall trend right now. Try again in a bit.", highlightedHours: [], chartFocus: "rainfall" };
    }

    var firstHalf = hours.slice(0, Math.floor(hours.length / 2));
    var secondHalf = hours.slice(Math.floor(hours.length / 2));

    var avgFirst = firstHalf.reduce(function (s, h) { return s + h.rainfall; }, 0) / firstHalf.length;
    var avgSecond = secondHalf.reduce(function (s, h) { return s + h.rainfall; }, 0) / secondHalf.length;

    var highlighted = hours.map(function (h) { return h.time; });
    var text;

    if (avgSecond > avgFirst + 0.5) {
      text = "It looks like the rain will get heavier over the next few hours, going from around " +
        avgFirst.toFixed(1) + " mm to " + avgSecond.toFixed(1) +
        " mm. You'll want to stay dry and keep that umbrella close.";
    } else if (avgFirst > avgSecond + 0.5) {
      text = "Good news! The rain is expected to ease off over the next few hours, dropping from around " +
        avgFirst.toFixed(1) + " mm to " + avgSecond.toFixed(1) +
        " mm. Things should feel a bit better later.";
    } else {
      text = "The rain looks fairly steady for the next few hours, holding at around " +
        avgFirst.toFixed(1) + " mm. Nothing dramatic, but you may still want to keep an umbrella with you.";
    }

    context.lastIntent = "RAIN_TREND";
    return { text: text, highlightedHours: highlighted, chartFocus: "rainfall" };
  }

  function handlePeakRain(data) {
    var hours = WS.getNextHours(data, 8);
    if (hours.length === 0) {
      return { text: "No forecast data available right now. Please check back shortly.", highlightedHours: [], chartFocus: "rainfall" };
    }

    var peak = hours.reduce(function (a, b) { return a.rainfall > b.rainfall ? a : b; });

    var text;
    if (peak.rainfall === 0) {
      text = "No rain is expected for the next several hours. Looks like smooth sailing! " +
        "A lovely stretch to enjoy some time outside.";
      context.lastReferencedTime = null;
    } else {
      text = "The heaviest rain is expected around " + formatTime(peak.time) +
        ", with about " + peak.rainfall + " mm of " +
        WS.getRainfallLabel(peak.rainfall).toLowerCase() + " rainfall. " +
        "You might want to plan around that window. Stay indoors or keep an umbrella ready.";
      context.lastReferencedTime = peak.time;
    }

    context.lastIntent = "PEAK_RAIN";
    return { text: text, highlightedHours: [peak.time], chartFocus: "rainfall" };
  }

  function handleOutdoorWindow(data) {
    var hours = WS.getNextHours(data, 8);
    if (hours.length === 0) {
      return { text: "I don't have enough data to suggest a good time right now. Please try again shortly.", highlightedHours: [], chartFocus: null };
    }

    var bestStart = -1;
    var bestLen = 0;
    var curStart = -1;
    var curLen = 0;

    for (var i = 0; i < hours.length; i++) {
      var isGood = hours[i].rainfall < 0.5 && hours[i].cloudCover < 85;
      if (isGood) {
        if (curStart === -1) curStart = i;
        curLen++;
      } else {
        if (curLen > bestLen) {
          bestLen = curLen;
          bestStart = curStart;
        }
        curStart = -1;
        curLen = 0;
      }
    }
    if (curLen > bestLen) {
      bestLen = curLen;
      bestStart = curStart;
    }

    var text;
    var highlighted;

    if (bestLen === 0) {
      var minRainIdx = 0;
      for (var j = 1; j < hours.length; j++) {
        if (hours[j].rainfall < hours[minRainIdx].rainfall) minRainIdx = j;
      }
      text = "It's looking a bit wet out there for the next several hours, unfortunately. " +
        "If you do need to head out, the lightest rain is expected around " +
        formatTime(hours[minRainIdx].time) + " at " + hours[minRainIdx].rainfall +
        " mm. Definitely bring an umbrella and take care.";
      highlighted = [hours[minRainIdx].time];
      context.lastReferencedTime = hours[minRainIdx].time;
    } else {
      var windowHours = hours.slice(bestStart, bestStart + bestLen);
      highlighted = windowHours.map(function (h) { return h.time; });
      text = "Your best window for heading outside looks to be around " +
        formatTime(windowHours[0].time) + " to " +
        formatTime(windowHours[windowHours.length - 1].time) + ". ";
      if (bestStart > 0) {
        text += "The rain should ease up before then. ";
      }
      text += "A nice stretch for a walk or some fresh air. Enjoy it!";
      context.lastReferencedTime = windowHours[0].time;
    }

    context.lastIntent = "OUTDOOR_WINDOW";
    return { text: text, highlightedHours: highlighted, chartFocus: null };
  }

  function handleWeatherTrend(data) {
    var hours = WS.getNextHours(data, 6);
    if (hours.length < 2) {
      return { text: "Not enough forecast data to paint the full picture right now. Check back soon.", highlightedHours: [], chartFocus: null };
    }

    var parts = [];
    var highlighted = hours.map(function (h) { return h.time; });

    var tempStart = hours[0].temperature;
    var tempEnd = hours[hours.length - 1].temperature;
    var tempDiff = tempEnd - tempStart;
    if (tempDiff >= 2) {
      parts.push("It'll warm up a bit.from " + tempStart + "°C to " + tempEnd + "°C.");
    } else if (tempDiff <= -2) {
      parts.push("It's going to cool down, dropping from " + tempStart + "°C to " + tempEnd + "°C. You might want a light layer.");
    } else {
      parts.push("Temperature stays comfortable around " + tempStart + "°C.");
    }

    var rainyHours = hours.filter(function (h) { return h.rainfall > 0; });
    if (rainyHours.length === 0) {
      parts.push("No rain expected.a nice stretch ahead.");
    } else {
      var peak = rainyHours.reduce(function (a, b) { return a.rainfall > b.rainfall ? a : b; });
      if (rainyHours.length === hours.length) {
        parts.push("Rain throughout the period, heaviest around " + formatTime(peak.time) + ". Keep that umbrella handy.");
      } else {
        parts.push("Expect some rain between " + formatTime(rainyHours[0].time) +
          " and " + formatTime(rainyHours[rainyHours.length - 1].time) +
          ", heaviest around " + formatTime(peak.time) + ". Plan accordingly.");
      }
      context.lastReferencedTime = peak.time;
    }

    var cloudStart = hours[0].cloudCover;
    var cloudEnd = hours[hours.length - 1].cloudCover;
    var cloudDiff = cloudEnd - cloudStart;
    if (cloudDiff >= 20) {
      parts.push("Skies will get cloudier as the day goes on.");
    } else if (cloudDiff <= -20) {
      parts.push("The skies should clear up later.something to look forward to.");
    }

    context.lastIntent = "WEATHER_TREND";
    return { text: parts.join(" "), highlightedHours: highlighted, chartFocus: null };
  }

  function handleCloudCover(data) {
    var hours = WS.getNextHours(data, 6);
    if (hours.length === 0) {
      return { text: "No cloud cover data available right now.", highlightedHours: [], chartFocus: "cloudcover" };
    }

    var current = hours[0].cloudCover;
    var peak = hours.reduce(function (a, b) { return a.cloudCover > b.cloudCover ? a : b; });
    var last = hours[hours.length - 1];
    var highlighted = hours.map(function (h) { return h.time; });

    var text;
    if (peak.cloudCover > current + 10) {
      text = "Cloud cover is building up, from about " + current +
        "% now to around " + peak.cloudCover + "% by " + formatTime(peak.time) + ".";
      if (last.cloudCover < peak.cloudCover - 10) {
        text += " But it should clear a bit later, dropping to " + last.cloudCover + "%. Hang in there.";
      }
    } else if (current > last.cloudCover + 10) {
      text = "The skies are expected to clear up, going from " + current +
        "% cloud cover now to around " + last.cloudCover + "% by " + formatTime(last.time) +
        ". Brighter times ahead!";
    } else {
      if (current < 30) {
        text = "Clear skies ahead! Cloud cover stays nice and low around " + current +
          "%. Perfect weather to get outside and enjoy the sunshine. Don't forget your hat!";
      } else {
        text = "Cloud cover will stay around " + current +
          "% over the next few hours. " + WS.getCloudLabel(current) +
          " conditions. Comfortable enough for being outdoors.";
      }
    }

    context.lastReferencedTime = peak.time;
    context.lastIntent = "CLOUD_COVER";
    return { text: text, highlightedHours: highlighted, chartFocus: "cloudcover" };
  }

  function handleAirQuality(data) {
    if (!data.psi) {
      return {
        text: "I don't have air quality data available right now. Please check back shortly.",
        highlightedHours: [],
        chartFocus: null,
      };
    }

    var psi = data.psi.value;
    var label = WS.getPSILabel(psi);
    var regions = data.psi.regions;
    var text;

    if (psi <= 50) {
      text = "The air quality is " + label.toLowerCase() + " right now, with a PSI of " + psi +
        ". Great conditions to spend time outdoors. Enjoy the fresh air!";
    } else if (psi <= 100) {
      text = "Air quality is " + label.toLowerCase() + " at PSI " + psi +
        ". It's generally fine for outdoor activities, though if you have respiratory sensitivities, you may want to take it easy.";
    } else if (psi <= 200) {
      text = "Air quality is " + label.toLowerCase() + " at PSI " + psi +
        ". You might want to limit time outdoors, especially if you have breathing difficulties. Take care of yourself.";
    } else {
      text = "Air quality is " + label.toLowerCase() + " at PSI " + psi +
        ". It's best to stay indoors if possible. Please take care and keep windows closed.";
    }

    if (regions) {
      var regionParts = [];
      Object.keys(regions).forEach(function (r) {
        regionParts.push(r.charAt(0).toUpperCase() + r.slice(1) + ": " + regions[r]);
      });
      text += " By region: " + regionParts.join(", ") + ".";
    }

    context.lastIntent = "AIR_QUALITY";
    return { text: text, highlightedHours: [], chartFocus: null };
  }

  function handleFollowup(data, time) {
    var hours = data.hourly;
    var match = hours.find(function (h) { return h.time === time; });
    if (!match) {
      match = hours.reduce(function (a, b) {
        return Math.abs(new Date(a.time) - new Date(time)) < Math.abs(new Date(b.time) - new Date(time)) ? a : b;
      });
    }

    if (!match) {
      return { text: "I couldn't find data for that time. Try asking about a specific hour.", highlightedHours: [], chartFocus: null };
    }

    var rainNote = match.rainfall > 0
      ? "Rainfall of " + match.rainfall + " mm (" + WS.getRainfallLabel(match.rainfall).toLowerCase() + ").bring an umbrella."
      : "No rainfall expected. You're all clear.";

    var text = "Around " + formatTime(match.time) + ", it's looking like " +
      match.temperature + "°C with " + match.cloudCover + "% cloud cover. " + rainNote;

    return { text: text, highlightedHours: [match.time], chartFocus: null };
  }

  // --- Specific time / area questions (uses the map's area forecast) ---

  var RAIN_WORDS = /rain|wet|umbrella|shower|storm|thunder|dry|drizzle|pour|weather/i;
  var NUM_WORDS = { a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, half: 0.5 };

  function clock(d) {
    var h = d.getHours();
    var m = d.getMinutes();
    return (h % 12 || 12) + (m ? ":" + String(m).padStart(2, "0") : "") + " " + (h >= 12 ? "PM" : "AM");
  }

  function clockWithDay(d) {
    var today = new Date();
    return clock(d) + (d.getDate() !== today.getDate() ? " tomorrow" : "");
  }

  function parseTargetTime(query) {
    var q = query.toLowerCase();
    var now = new Date();
    var m;

    m = q.match(/\bin (\d+(?:\.\d+)?|an?|one|two|three|four|five|six|half an?)\s*(hours?|hrs?|minutes?|mins?)\b/);
    if (m) {
      var n = NUM_WORDS[m[1].split(" ")[0]];
      if (n == null) n = parseFloat(m[1]);
      var mins = /^h/.test(m[2]) ? n * 60 : n;
      return new Date(now.getTime() + mins * 60000);
    }

    var h = null, min = 0, mer = null;
    if ((m = q.match(/\b(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)(?![a-z])/))) {
      h = parseInt(m[1], 10); min = m[2] ? parseInt(m[2], 10) : 0; mer = m[3].charAt(0);
    } else if ((m = q.match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/))) {
      h = parseInt(m[1], 10); min = parseInt(m[2], 10); mer = h > 12 || h === 0 ? "24" : null;
    } else if ((m = q.match(/\b(?:at|by|around|about|before|after|until|till)\s+(\d{1,2})(?![\d:])/))) {
      h = parseInt(m[1], 10);
    } else if (/\bnoon\b|\bmidday\b/.test(q)) { h = 12; mer = "24"; }
    else if (/\bmidnight\b/.test(q)) { h = 0; mer = "24"; }
    else if (/\bthis morning\b|\bin the morning\b/.test(q)) { h = 9; mer = "24"; }
    else if (/\bafternoon\b/.test(q)) { h = 15; mer = "24"; }
    else if (/\bevening\b/.test(q)) { h = 18; mer = "24"; }
    else if (/\btonight\b/.test(q)) { h = 21; mer = "24"; }

    if (h === null || h > 23 || min > 59) return null;
    if (mer === "p" && h < 12) h += 12;
    if (mer === "a" && h === 12) h = 0;

    var d = new Date(now);
    d.setHours(h, min, 0, 0);
    var grace = now.getTime() - 30 * 60000;
    if (!mer && h < 12 && d.getTime() < grace) d = new Date(d.getTime() + 12 * 3600000);
    if (d.getTime() < grace) d = new Date(d.getTime() + 24 * 3600000);
    if (/\btomorrow\b/.test(q) && d.getDate() === now.getDate()) d = new Date(d.getTime() + 24 * 3600000);
    return d;
  }

  function findArea(query, mapData) {
    if (!mapData || !mapData.forecasts) return null;
    var q = query.toLowerCase();
    var sorted = mapData.forecasts.slice().sort(function (a, b) { return b.area.length - a.area.length; });
    return sorted.find(function (f) { return q.indexOf(f.area.toLowerCase()) >= 0; }) || null;
  }

  function homeArea(data, mapData) {
    if (!mapData || !mapData.forecasts || !mapData.forecasts.length) return null;
    var loc = (data.location || "").replace(/\s*\(.*\)\s*/g, "").toLowerCase();
    if (loc) {
      var byName = mapData.forecasts.find(function (f) {
        var a = f.area.toLowerCase();
        return loc.indexOf(a) >= 0 || a.indexOf(loc) >= 0;
      });
      if (byName) return { area: byName, nearest: false };
    }
    var c = data.coords || WS.DEFAULT_COORDS;
    var best = null, bestD = Infinity;
    mapData.forecasts.forEach(function (f) {
      if (!f.lat) return;
      var d = Math.pow(f.lat - c.lat, 2) + Math.pow(f.lon - c.lon, 2);
      if (d < bestD) { bestD = d; best = f; }
    });
    return best ? { area: best, nearest: true } : null;
  }

  function classifyForecast(text) {
    var t = text.toLowerCase();
    if (t.indexOf("thunder") >= 0) return "thundery";
    if (t.indexOf("heavy") >= 0) return "heavy";
    if (/shower|rain|drizzle/.test(t)) return "showers";
    return "dry";
  }

  function nearestStation(area, mapData) {
    if (!mapData || !mapData.stations || !mapData.stations.length || !area || !area.lat) return null;
    var best = null, bestD = Infinity;
    mapData.stations.forEach(function (s) {
      var d = Math.pow(s.lat - area.lat, 2) + Math.pow(s.lon - area.lon, 2);
      if (d < bestD) { bestD = d; best = s; }
    });
    return bestD < 0.0025 ? best : null; // roughly within 5 km
  }

  function findHour(data, target) {
    var t = target.getTime();
    return (data.hourly || []).find(function (h) {
      var s = new Date(h.time).getTime();
      return t >= s && t < s + 3600000;
    }) || null;
  }

  function handleTimeQuery(data, mapData, target, namedArea) {
    var now = Date.now();
    var offsetMin = (target.getTime() - now) / 60000;
    var isNow = Math.abs(offsetMin) < 5;
    var when = isNow ? "right now" : "around " + clockWithDay(target);
    var home = namedArea ? null : homeArea(data, mapData);
    var area = namedArea || (home && home.area);
    var areaLabel = area ? area.area + (home && home.nearest ? ", the nearest forecast area to you," : "") : "";
    var hour = findHour(data, target);
    var text;

    if (offsetMin < -30) {
      text = clock(target) + " has already passed. ";
      text += hour
        ? "The forecast for that hour showed " + (hour.rainfall > 0 ? hour.rainfall + " mm of rain." : "no rain.")
        : "You can slide the map back up to 2 hours to see past radar.";
    } else if (offsetMin <= 120 && area) {
      var cat = classifyForecast(area.forecast);
      text = "The map's 2-hour forecast for " + areaLabel + " shows " + area.forecast.toLowerCase() + ". ";
      if (cat === "dry") {
        text += "So it should stay dry " + when + ". ";
      } else if (cat === "thundery" || cat === "heavy") {
        text += "So yes, expect " + (cat === "thundery" ? "thundery" : "heavy") + " rain " + when + ". Best to stay indoors or keep an umbrella close. ";
      } else {
        text += "So yes, some rain is likely " + when + ". Bring an umbrella. ";
      }
      var st = nearestStation(area, mapData);
      if (st && offsetMin <= 30) {
        text += st.value > 0
          ? "The nearest rain gauge, at " + st.name + ", is picking up " + st.value + " mm right now."
          : "The nearest rain gauge, at " + st.name + ", is dry at the moment.";
      }
    } else if (hour) {
      text = (isNow ? "Right now" : "Around " + clockWithDay(target)) + ", the hourly forecast shows " +
        (hour.rainfall > 0
          ? WS.getRainfallLabel(hour.rainfall).toLowerCase() + " rain, about " + hour.rainfall + " mm, "
          : "no rain, ") +
        "with " + hour.cloudCover + "% cloud cover.";
      if (offsetMin > 120) {
        text += " That's beyond the map's 2-hour area forecast, so treat it as a rough guide.";
        if (namedArea) text += " It covers your location generally, not " + namedArea.area + " specifically.";
      }
    } else {
      text = "I only have forecasts for about the next day. Try asking about a time within that range.";
    }

    context.lastReferencedTime = hour ? hour.time : null;
    context.lastIntent = "SPECIFIC_TIME";
    return {
      text: text.trim(),
      highlightedHours: hour ? [hour.time] : [],
      chartFocus: "rainfall",
      focusTime: new Date(target).toISOString(),
    };
  }

  function handleUnknown() {
    return {
      text: "I'm not sure how to help with that one, but I'd love to try something else. You can ask me about rainfall, cloud cover, air quality, or the best time to head outdoors.",
      highlightedHours: [],
      chartFocus: null,
      suggestQuestions: true,
    };
  }

  function processQuery(query, weatherData, mapData) {
    if (!weatherData) {
      return {
        text: "Just a moment.I'm still loading the latest weather data. Try again in a few seconds.",
        highlightedHours: [],
        chartFocus: null,
      };
    }

    var intent = matchIntent(query);

    if (intent.id !== "FOLLOWUP" && RAIN_WORDS.test(query)) {
      var target = parseTargetTime(query);
      var namedArea = findArea(query, mapData);
      if (target || namedArea) {
        return handleTimeQuery(weatherData, mapData, target || new Date(), namedArea);
      }
    }

    switch (intent.id) {
      case "CURRENT_CONDITIONS": return handleCurrentConditions(weatherData);
      case "NEXT_HOUR_RAIN": return handleNextHourRain(weatherData);
      case "RAIN_TREND": return handleRainTrend(weatherData);
      case "PEAK_RAIN": return handlePeakRain(weatherData);
      case "OUTDOOR_WINDOW": return handleOutdoorWindow(weatherData);
      case "WEATHER_TREND": return handleWeatherTrend(weatherData);
      case "CLOUD_COVER": return handleCloudCover(weatherData);
      case "AIR_QUALITY": return handleAirQuality(weatherData);
      case "FOLLOWUP": return handleFollowup(weatherData, intent.time);
      default: return handleUnknown();
    }
  }

  return {
    processQuery: processQuery,
  };
})();
