/*
 * Values extracted from apex-dashboard.png (Apex Financial Overview).
 * Printed figures (KPI cards) are exact. Bar values are read off the image,
 * rounded, and marked approx: true. A person must check every value
 * against the image before this is used. Monetary values are in £ millions.
 */
window.APEX_DATA = {
  source: "apex-dashboard.png",
  checked: false, // set to true once a person has compared every value with the image
  kpis: [
    { id: "revenue", label: "Revenue", value: 12.5, changeVsLY: 15.2, status: "Above target", trend: "Rising steadily month on month" },
    { id: "profit", label: "Profit", value: 4.3, changeVsLY: 60.7, status: "Above target", trend: "Rising, with the sharpest growth from 2026" },
    { id: "cogs", label: "Cost of goods sold", value: 8.2, changeVsLY: 0.2, status: "Under budget", trend: "Flat" },
    { id: "expenses", label: "Expenses", value: 24.0, changeVsLY: 16.9, status: "Over budget", trend: "Stepping up, over budget in most months" },
  ],
  // Bars with their reference marker: target (revenue, profit) or budget (COGS, expenses).
  byUnit: {
    revenue:  { ref: "target", rows: [["Consulting", 6.8, 7.7], ["Managed Services", 7.0, 7.7], ["Software", 18.9, 15.2]] },
    profit:   { ref: "target", rows: [["Consulting", -1.2, -1.0], ["Managed Services", -1.2, -1.0], ["Software", 10.6, 6.3]] },
    cogs:     { ref: "budget", rows: [["Consulting", 8.2, 8.7], ["Managed Services", 8.2, 8.7], ["Software", 8.2, 8.7]] },
    expenses: { ref: "budget", rows: [["Consulting", 22.2, 19.8], ["Managed Services", 22.2, 19.8], ["Software", 22.2, 19.8]] },
  },
  byRegion: {
    revenue:  { ref: "target", rows: [["APAC", 12.1, 10.2], ["EMEA", 10.3, 10.2], ["North America", 10.5, 10.2]] },
    profit:   { ref: "target", rows: [["APAC", 4.9, 1.5], ["EMEA", 1.8, 1.5], ["North America", 1.8, 1.5]] },
    cogs:     { ref: "budget", rows: [["APAC", 7.3, 8.7], ["EMEA", 8.6, 8.7], ["North America", 8.6, 8.7]] },
    expenses: { ref: "budget", rows: [["APAC", 22.2, 19.8], ["EMEA", 22.2, 19.8], ["North America", 22.2, 19.8]] },
  },
  // Revenue minus target, by business unit and region.
  revenueVariance: [
    ["Consulting", "APAC", 0.0], ["Consulting", "EMEA", -0.35], ["Consulting", "North America", -0.35],
    ["Managed Services", "APAC", 0.0], ["Managed Services", "EMEA", -0.3], ["Managed Services", "North America", -0.3],
    ["Software", "APAC", 2.0], ["Software", "EMEA", 1.05], ["Software", "North America", 1.1],
  ],
  departments: [
    ["Cloud Infrastructure", "Cost of goods sold", 13.5],
    ["Direct Delivery", "Cost of goods sold", 13.5],
    ["G&A", "Operating expenses", 14.0],
    ["R&D", "Operating expenses", 28.7],
    ["Sales & Marketing", "Operating expenses", 24.4],
  ],
  // Monthly charts, 2024 to 2027: summarised in words, values too small to read reliably.
  monthly: {
    revenue: "Rises from about 0.6 million pounds a month in early 2024 to about 1 million pounds a month by 2027. Below target in early 2024, above target from mid 2024 onwards.",
    profit: "Rises from close to zero in 2024 to about 0.4 million pounds a month by 2027, with the steepest rise during 2026.",
    cogs: "Flat at roughly 0.5 to 0.6 million pounds a month throughout, under budget in every month.",
    expenses: "Between about 1.2 and 2 million pounds a month, stepping up during 2025 and 2026. Over budget in most months from 2025.",
  },
};
